# The UniVault Project
A universal vault that can be accessed from anywhere in the server.
Kit submissions, item management, NBT Archives!
https://www.spigotmc.org/resources/universalvaults.106973/

- /vault <page number>
- /view [all|shulker|random] <page number>
- /submit
- /submit delete <index>
- /handpicked [create|delete|open|edit|teleport] <handpicked kit>
- /archive [generate|delete|teleport|setair|setorigin]
- /givesubmissionchest
- /readitem
- /testitem

-----------------------------------------------------------
For: @1sKq, NBTArchives.minehut.gg
